package aima.core.logic.fol;

/**
 * @author Ciaran O'Reilly
 * 
 */
public interface StandardizeApartIndexical {
	String getPrefix();

	int getNextIndex();
}